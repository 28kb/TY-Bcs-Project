<?php
session_start();
pg_connect("host=127.0.0.1 user=postgres password=postgres dbname=skg");
?>
<link rel="stylesheet" href="css/mdb.min.css" />

